from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from .forms import SignUpForm, StudentProfileForm
from .models import StudentProfile, MCQ, TestResult
from django.contrib.auth.decorators import login_required
import random
from .models import TestResult
from .models import University
from django.shortcuts import render, get_object_or_404

def index_view(request):
    return redirect('welcome')

# Signup view
def signup_view(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            StudentProfile.objects.create(user=user, full_name="", phone="", field_of_interest="")
            return redirect('login')
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})

# Login view
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('Main')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})


def welcome_view(request):
    return render(request, 'core/welcome.html')

@login_required
def create_profile_view(request):
    # Get or create ensures only one instance per user
    student_profile, created = StudentProfile.objects.get_or_create(user=request.user)

    if request.method == 'POST':
        form = StudentProfileForm(request.POST, request.FILES, instance=student_profile)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = StudentProfileForm(instance=student_profile)

    return render(request, 'core/create_profile.html', {'form': form})

@login_required
def profile_view(request):
    student_profile = StudentProfile.objects.get(user=request.user)
    profile_image = student_profile.profile_image if student_profile.profile_image else None
    return render(request, 'core/profile.html', {'profile': student_profile, 'profile_image': profile_image})

@login_required
def update_profile_view(request):
    student_profile = StudentProfile.objects.get(user=request.user)
    
    if request.method == 'POST':
        form = StudentProfileForm(request.POST, request.FILES, instance=student_profile)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = StudentProfileForm(instance=student_profile)

    return render(request, 'core/update_profile.html', {'form': form})

def home(request):
    return HttpResponse("Welcome to Student Advisory Portal!")
def Main_view(request):
    return render(request, 'Main.html')
def generate_test(user):
    student_profile = StudentProfile.objects.get(user=user)
    field = student_profile.field_of_interest

    mcqs = {}

    if field == 'IT/Computer Science':
        mcqs = {
            'Computer Science': MCQ.objects.filter(category='Computer Science').order_by('?')[:30],
            'General Maths': MCQ.objects.filter(category='General Maths').order_by('?')[:30],
            'General Science': MCQ.objects.filter(category='General Science').order_by('?')[:30],
            'English': MCQ.objects.filter(category='English').order_by('?')[:10],
        }
    elif field == 'Business Administration' or field == 'Business':
        mcqs = {
            'Business': MCQ.objects.filter(category='Business').order_by('?')[:30],
            'General Maths': MCQ.objects.filter(category='General Maths').order_by('?')[:30],
            'English': MCQ.objects.filter(category='English').order_by('?')[:10],
            'General Science': MCQ.objects.filter(category='General Science').order_by('?')[:30],
        }
    elif field == 'Economics':
        mcqs = {
            'Business': MCQ.objects.filter(category='Business').order_by('?')[:30],
            'General Maths': MCQ.objects.filter(category='General Maths').order_by('?')[:30],
            'English': MCQ.objects.filter(category='English').order_by('?')[:10],
            'General Science': MCQ.objects.filter(category='General Science').order_by('?')[:30],
        }
    elif field == 'Commerce':
        mcqs = {
            'Business': MCQ.objects.filter(category='Business').order_by('?')[:30],
            'General Maths': MCQ.objects.filter(category='General Maths').order_by('?')[:30],
            'English': MCQ.objects.filter(category='English').order_by('?')[:10],
            'General Science': MCQ.objects.filter(category='General Science').order_by('?')[:30],
        }
    elif field == 'Medicine' or field == 'Biological Sciences':
        mcqs = {
            'Biology': MCQ.objects.filter(category='Biology').order_by('?')[:30],
            'Physics': MCQ.objects.filter(category='Physics').order_by('?')[:30],
            'Chemistry': MCQ.objects.filter(category='Chemistry').order_by('?')[:30],
            'English': MCQ.objects.filter(category='English').order_by('?')[:10],
        }
    elif field == 'Pharmacy':
        mcqs = {
            'Biology': MCQ.objects.filter(category='Biology').order_by('?')[:30],
            'Physics': MCQ.objects.filter(category='Physics').order_by('?')[:30],
            'Chemistry': MCQ.objects.filter(category='Chemistry').order_by('?')[:30],
            'English': MCQ.objects.filter(category='English').order_by('?')[:10],
        }
    elif field == 'Health Sciences' or field == 'Veterinary Sciences':
        mcqs = {
            'Biology': MCQ.objects.filter(category='Biology').order_by('?')[:30],
            'Physics': MCQ.objects.filter(category='Physics').order_by('?')[:30],
            'Chemistry': MCQ.objects.filter(category='Chemistry').order_by('?')[:30],
            'English': MCQ.objects.filter(category='English').order_by('?')[:10],
        }
    elif field == 'Engineering' or field == 'Science':
        mcqs = {
            'Physics': MCQ.objects.filter(category='Physics').order_by('?')[:30],
            'Chemistry': MCQ.objects.filter(category='Chemistry').order_by('?')[:30],
            'Mathematics': MCQ.objects.filter(category='Mathematics').order_by('?')[:30],
            'English': MCQ.objects.filter(category='English').order_by('?')[:10],
        }
    elif field == 'Humanities':
        mcqs = {
            'General Science': MCQ.objects.filter(category='General Science').order_by('?')[:40],
            'General Maths': MCQ.objects.filter(category='General Maths').order_by('?')[:30],
            'English': MCQ.objects.filter(category='English').order_by('?')[:30],
        }
    elif field == 'Education':
        mcqs = {
            'General Science': MCQ.objects.filter(category='General Science').order_by('?')[:40],
            'General Maths': MCQ.objects.filter(category='General Maths').order_by('?')[:30],
            'English': MCQ.objects.filter(category='English').order_by('?')[:30],
        }
    elif field == 'Media & Communications':
        mcqs = {
            'General Science': MCQ.objects.filter(category='General Science').order_by('?')[:30],
            'General Maths': MCQ.objects.filter(category='General Maths').order_by('?')[:30],
            'English': MCQ.objects.filter(category='English').order_by('?')[:40],
        }
    elif field == 'Social Sciences':
        mcqs = {
            'General Science': MCQ.objects.filter(category='General Science').order_by('?')[:40],
            'General Maths': MCQ.objects.filter(category='General Maths').order_by('?')[:40],
            'English': MCQ.objects.filter(category='English').order_by('?')[:20],
        }
    elif field == 'Fine Arts/Design':
        mcqs = {
            'General Science': MCQ.objects.filter(category='General Science').order_by('?')[:30],
            'General Maths': MCQ.objects.filter(category='General Maths').order_by('?')[:40],
            'English': MCQ.objects.filter(category='English').order_by('?')[:30],
        }
    elif field == 'Environmental Sciences':
        mcqs = {
            'Biology': MCQ.objects.filter(category='Biology').order_by('?')[:30],
            'Chemistry': MCQ.objects.filter(category='Chemistry').order_by('?')[:30],
            'General Science': MCQ.objects.filter(category='General Science').order_by('?')[:30],
            'English': MCQ.objects.filter(category='English').order_by('?')[:10],
        }
    elif field == 'Agriculture':
        mcqs = {
            'Biology': MCQ.objects.filter(category='Biology').order_by('?')[:30],
            'Chemistry': MCQ.objects.filter(category='Chemistry').order_by('?')[:30],
            'General Science': MCQ.objects.filter(category='General Science').order_by('?')[:30],
            'English': MCQ.objects.filter(category='English').order_by('?')[:10],
        }

    return mcqs




@login_required
def test_view(request):
    user = request.user
    mcqs = generate_test(user)
    
    context = {
        'mcqs': mcqs,
    }
    return render(request, 'test.html', context)



def submit_test_view(request):
    if request.method == 'POST':
        selected_answers = {}
        correct_count = 0
        total_questions = 0

        # Loop through the submitted answers from the POST request
        for question_id, selected_option in request.POST.items():
            if question_id.startswith('question_'):
                question_id = int(question_id.split('_')[1])

                try:
                    question = MCQ.objects.get(id=question_id)
                except MCQ.DoesNotExist:
                    continue

                total_questions += 1
                correct_answer = question.correct_option.strip()

                # Map 'option1' -> 'A', 'option2' -> 'B', etc.
                option_map = {
                    'option1': 'A',
                    'option2': 'B',
                    'option3': 'C',
                    'option4': 'D'
                }
                mapped_selected_option = option_map.get(selected_option.strip())

                # Compare the mapped selected option with the correct answer
                if mapped_selected_option == correct_answer:
                    correct_count += 1

                # Store selected and correct answers for display later
                selected_answers[question] = {
                    'selected': mapped_selected_option,
                    'correct': correct_answer,
                }

        # Save the result to the database
        TestResult.objects.create(
            user=request.user,
            score=correct_count,  # Store the number of correct answers as score
            total_questions=total_questions,
            correct_answers=correct_count
        )

        # Pass the context with calculated values
        context = {
            'selected_answers': selected_answers,
            'correct_count': correct_count,
            'total_questions': total_questions,
            'score': correct_count,  # Pass the score to the template
        }

        return render(request, 'test_results.html', context)

    return redirect('test_page')



@login_required
def test_results_view(request):
    # Get all test results for the logged-in user, ordered by the latest test date
    results = TestResult.objects.filter(user=request.user).order_by('-test_date')
    
    # Fetch the `Student` object for the logged-in user
    student = get_object_or_404(StudentProfile, user=request.user)
    
    # Use the latest test result for test_score display
    latest_result = results.first() if results.exists() else None
    test_score = latest_result.score if latest_result else None  # Use 'score' field instead of 'test_score'

    # Sample data for selected answers (update this according to your logic)
    # This is a placeholder; actual data should be passed here.
    selected_answers = {
        "A synonym for 'diligent' is": {"selected": "C", "correct": "B"},
        # Add more questions here as per your data
    }

    # Pass 'student', 'test_score', 'results', and 'selected_answers' to the template
    return render(request, 'core/test_results.html', {
        'results': results,
        'student': student,
        'test_score': test_score,
        'selected_answers': selected_answers  # Pass sample data for answers
    })

def check_eligibility(student, university):
    # Sample logic to check eligibility
    # Compare student test score or academic background with university criteria
    required_score = int(university.eligibility_criteria)  # Assumed criteria to be an integer score
    return student.test_score >= required_score

def get_recommendations(request, student_id):
    student = StudentProfile.objects.get(id=student_id)

    # Convert intermediate_marks_percentage to a float for comparison
    try:
        intermediate_marks = float(student.intermediate_marks_percentage)
    except ValueError:
        intermediate_marks = 0  # Default to 0 if conversion fails

    # Filter universities by field of interest
    eligible_universities = University.objects.filter(field=student.field_of_interest)

    # Get filter values from the request
    filter_by_rank = request.GET.get('filter_by_rank', None)
    selected_city = request.GET.get('city', None)
    filter_by_fee = request.GET.get('filter_by_fee', None)

    # Apply area-wise filter if city is provided
    if selected_city:
        eligible_universities = eligible_universities.filter(name__icontains=selected_city)

    # Apply fee-wise sorting based on the selected option
    if filter_by_fee == 'low_to_high':
        eligible_universities = eligible_universities.order_by('fee_structure')
    elif filter_by_fee == 'high_to_low':
        eligible_universities = eligible_universities.order_by('-fee_structure')

    # Apply rank-wise sorting if selected
    if filter_by_rank == 'ascending':
        eligible_universities = eligible_universities.order_by('rank')
    elif filter_by_rank == 'descending':
        eligible_universities = eligible_universities.order_by('-rank')

    # Calculate probability of success and prepare recommendations
    recommendations = [
        {
            'university': uni.name,
            'program': uni.degree_programs,
            'field': uni.field,
            'eligibility_criteria': uni.eligibility_criteria,
            'fee_structure': uni.fee_structure,  # Include fee structure in recommendations
            'rank': uni.rank,
            'probability_of_success': calculate_probability(student, uni)
        }
        for uni in eligible_universities
    ]

    # Pass filter values to the template for display
    return render(request, 'recommendations.html', {
        'recommendations': recommendations,
        'selected_city': selected_city,
        'filter_by_fee': filter_by_fee,
        'filter_by_rank': filter_by_rank,
    })

def calculate_probability(student, university):
    # Retrieve the most recent test result for the student
    test_result = TestResult.objects.filter(user=student.user).order_by('-test_date').first()
    
    # Check if a test result exists
    if test_result:
        score_factor = test_result.score / 100  # Scale test score to be a multiplier
    else:
        score_factor = 0.5  # Default score factor if no test result is found
    
    # Define base probability inversely related to the university's rank
    if university.rank:
        base_probability = max(1, 100 - (university.rank * 2))  # Example: Rank 1 = 98%, Rank 10 = 80%, etc.
        adjusted_probability = base_probability * score_factor
        return min(100, round(adjusted_probability))  # Ensure probability does not exceed 100%
    
    # Default probability if no rank is available
    return 50  # Assume a base 50% if rank is missing
