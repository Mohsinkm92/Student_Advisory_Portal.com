from django.contrib.auth.models import User
from django.core.validators import RegexValidator
from django.db import models

class StudentProfile(models.Model):
    FIELD_CHOICES = [
        ('IT/Computer Science', 'IT/Computer Science'),
        ('Business Administration', 'Business Administration'),
        ('Education', 'Education'),
        ('Humanities', 'Humanities'),
        ('Medicine', 'Medicine'),
        ('Engineering', 'Engineering'),
        ('Science', 'Science'),
        ('Agriculture', 'Agriculture'),
        ('Commerce', 'Commerce'),
        ('Veterinary Sciences', 'Veterinary Sciences'),
        ('Social Sciences', 'Social Sciences'),
        ('Economics', 'Economics'),
        ('Pharmacy', 'Pharmacy'),
        ('Health Sciences', 'Health Sciences'),
        ('Media & Communications', 'Media & Communications'),
        ('Fine Arts/Design', 'Fine Arts/Design'),
        ('Biological Sciences', 'Biological Sciences'),
        ('Business', 'Business'),
        ('Environmental Sciences', 'Environmental Sciences'),
    ]
    
    phone = models.CharField(
        max_length=13,
        validators=[RegexValidator(r'^(\+92|0)?3\d{9}$', message="Enter a correct Pakistani phone number.")]
    )
    
    intermediate_marks_percentage = models.CharField(
        max_length=5
    )
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True)
    full_name = models.CharField(max_length=100)
    field_of_interest = models.CharField(max_length=50, choices=FIELD_CHOICES)
    profile_image = models.ImageField(upload_to='profile_images/', blank=True, null=True)

    def __str__(self):
        return self.full_name




# University Model
class University(models.Model):
    name = models.CharField(max_length=200)
    city = models.CharField(max_length=100)
    degree_programs = models.TextField()
    field = models.CharField(max_length=100)
    eligibility_criteria = models.TextField()
    fee_structure = models.TextField()
    rank = models.IntegerField(null=True, blank=True)
    def __str__(self):
        return self.name




# MCQ Model
class MCQ(models.Model):
    SUBJECT_CHOICES = [
        ('Physics', 'Physics'),
        ('Chemistry', 'Chemistry'),
        ('Math', 'Math'),
        ('Biology', 'Biology'),
        ('Computer Science', 'Computer Science'),
        ('Business Administration', 'Business Administration'),
        ('Education', 'Education'),
        ('Humanities', 'Humanities'),
        ('Medicine', 'Medicine'),
        ('Engineering', 'Engineering'),
        ('Science', 'Science'),
        ('Agriculture', 'Agriculture'),
        ('Commerce', 'Commerce'),
        ('Veterinary Sciences', 'Veterinary Sciences'),
        ('Social Sciences', 'Social Sciences'),
        ('Economics', 'Economics'),
        ('Pharmacy', 'Pharmacy'),
        ('Health Sciences', 'Health Sciences'),
        ('Media & Communications', 'Media & Communications'),
        ('Fine Arts/Design', 'Fine Arts/Design'),
        ('Biological Sciences', 'Biological Sciences'),
        ('Environmental Sciences', 'Environmental Sciences'),
        ('Business', 'Business'),
    ]
    
    question = models.TextField()
    option1 = models.CharField(max_length=200)
    option2 = models.CharField(max_length=200)
    option3 = models.CharField(max_length=200)
    option4 = models.CharField(max_length=200)
    correct_option = models.CharField(max_length=200)
    subject = models.CharField(max_length=50, choices=SUBJECT_CHOICES)  # Subject related to the MCQ
    category = models.CharField(max_length=100)  # e.g., NTS, GAT, SAT, etc.

    def get_options(self):
        return {
            'option1': self.option1,
            'option2': self.option2,
            'option3': self.option3,
            'option4': self.option4,
        }

    def __str__(self):
        return f"{self.subject}: {self.question}"



# TestResult Model
class TestResult(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    score = models.IntegerField()  # Store the number of correct answers
    total_questions = models.IntegerField()  # Total number of questions
    correct_answers = models.IntegerField()  # Store number of correct answers
    test_date = models.DateTimeField(auto_now_add=True)  # Automatically store the test date

    def __str__(self):
        return f"{self.user.username} - {self.score} correct answers"

