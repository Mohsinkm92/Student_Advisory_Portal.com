from django.urls import path
from django.views.generic import RedirectView
from .views import (
    index_view,
    signup_view,
    login_view,
    test_view,
    welcome_view,
    Main_view,
    create_profile_view,
    profile_view,
    update_profile_view,
    submit_test_view,
    test_results_view,
)
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', RedirectView.as_view(url='/welcome/', permanent=False), name='home'),  # Redirect root to welcome
    path('Main/', Main_view, name='Main'),

    path('signup/', signup_view, name='signup'),
    path('login/', login_view, name='login'),
    path('welcome/', welcome_view, name='welcome'),  # Welcome page as first accessible page
    path('profile/create/', create_profile_view, name='create_profile'),
    path('profile/', profile_view, name='profile'),
    path('profile/update/', update_profile_view, name='update_profile'),
     path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    # Password reset URLs
    path('password_reset/', auth_views.PasswordResetView.as_view(template_name='core/password_reset.html'), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(template_name='core/password_reset_done.html'), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='core/password_reset_confirm.html'), name='password_reset_confirm'),
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(template_name='core/password_reset_complete.html'), name='password_reset_complete'),
    # Test-related URLs
    path('test/', test_view, name='test'),
    path('test/submit/', submit_test_view, name='submit_test'),  # URL for submitting the test
    path('test/results/', test_results_view, name='test_results'),  # URL for viewing test results
    path('recommendations/<int:student_id>/', views.get_recommendations, name='get_recommendations'),
]
