from django.contrib import admin
from .models import StudentProfile, University
from .models import MCQ
from .models import TestResult

class MCQAdmin(admin.ModelAdmin):
    list_display = ('question', 'subject', 'category')  # Show these columns in the admin list
    list_filter = ('subject', 'category')  # Add filters for easier navigation

admin.site.register(MCQ, MCQAdmin)



# Register StudentProfile
@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ['full_name', 'phone', 'field_of_interest','intermediate_marks_percentage']
    search_fields = ['full_name', 'email']

# Register University
@admin.register(University)
class UniversityAdmin(admin.ModelAdmin):
    list_display = ('name', 'city', 'degree_programs', 'field', 'eligibility_criteria', 'fee_structure', 'rank')
    search_fields = ['name', 'city', 'degree_programs', 'field', 'eligibility_criteria', 'fee_structure', 'rank']
    



@admin.register(TestResult)
class TestResultAdmin(admin.ModelAdmin):
    list_display = ('user', 'test_date', 'total_questions', 'correct_answers', 'get_score')
    search_fields = ('user__username',)
    list_filter = ('test_date',)  # Filtering by test date is still in place

    def get_score(self, obj):
        return f"{obj.correct_answers} / {obj.total_questions}"  # Show correct answers out of total questions

    get_score.short_description = 'Score'  # Set column name to 'Score'

