import pandas as pd
from django.core.management.base import BaseCommand
from core.models import MCQ

class Command(BaseCommand):
    help = 'Import MCQs from an Excel file with multiple sheets'

    def add_arguments(self, parser):
        parser.add_argument('file_path', type=str, help='Path to the Excel file')

    def handle(self, *args, **kwargs):
        file_path = kwargs['file_path']
        
        # Load the Excel file with multiple sheets
        xls = pd.ExcelFile(file_path)

        # Iterate over each sheet and import the MCQs
        for sheet_name in xls.sheet_names:
            df = pd.read_excel(xls, sheet_name=sheet_name)
            for index, row in df.iterrows():
                MCQ.objects.create(
                    question=row['Question'],
                    option1=row['Option A'],
                    option2=row['Option B'],
                    option3=row['Option C'],
                    option4=row['Option D'],
                    correct_option=row['Correct Option'],
                    category=sheet_name  # Using sheet name as category
                )

        self.stdout.write(self.style.SUCCESS('MCQs imported successfully from all sheets'))
