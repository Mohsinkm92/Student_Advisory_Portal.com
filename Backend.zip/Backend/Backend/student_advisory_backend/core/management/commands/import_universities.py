import pandas as pd
from django.core.management.base import BaseCommand
from core.models import University

class Command(BaseCommand):
    help = 'Imports university data from an Excel file'

    def add_arguments(self, parser):
        parser.add_argument('file_path', type=str, help='The path to the Excel file to import')

    def handle(self, *args, **kwargs):
        file_path = kwargs['file_path']
        data = pd.read_excel(file_path)

        for _, row in data.iterrows():
            University.objects.create(
                name=row['University'],
                degree_programs=row['Degree Programs'],
                field=row['Field'],
                eligibility_criteria=row['Eligibility Criteria'],
                fee_structure=row['Fee Structure (per semester)']
            )
        self.stdout.write(self.style.SUCCESS('University data imported successfully'))
