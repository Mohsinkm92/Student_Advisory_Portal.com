import pandas as pd
from django.core.management.base import BaseCommand
from core.models import University

class Command(BaseCommand):
    help = 'Imports university ranking data from an Excel file'

    def add_arguments(self, parser):
        parser.add_argument('file_path', type=str, help='The path to the Excel file to import')

    def handle(self, *args, **kwargs):
        file_path = kwargs['file_path']
        data = pd.read_excel(file_path)

        # Iterate through each row and update university rankings
        for _, row in data.iterrows():
            name = row['Name']
            ranking = row['Ranking']

            # Update all universities with the same name
            universities = University.objects.filter(name=name)
            if universities.exists():
                universities.update(rank=ranking)
                self.stdout.write(self.style.SUCCESS(f'Updated ranking for {name} to {ranking}'))
            else:
                self.stdout.write(self.style.WARNING(f'University "{name}" not found in the database'))
        
        self.stdout.write(self.style.SUCCESS('Ranking data import completed'))
