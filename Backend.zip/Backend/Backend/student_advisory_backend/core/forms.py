from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import StudentProfile  # Import your model
from .models import MCQ
import re
from django.core.validators import RegexValidator

class SignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    def save(self, commit=True):
        user = super(SignUpForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user



class StudentProfileForm(forms.ModelForm):
    class Meta:
        model = StudentProfile
        fields = ['full_name', 'phone', 'field_of_interest', 'profile_image', 'intermediate_marks_percentage']

    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        if not re.match(r'^(\+92|0)?3\d{9}$', phone):
            raise forms.ValidationError("Enter a correct Pakistani phone number.")
        return phone

    def clean_intermediate_marks_percentage(self):
        percentage = self.cleaned_data.get('intermediate_marks_percentage')
        if percentage is not None:  # Check if percentage is not None
            try:
                percentage = float(percentage)  # Convert to float to ensure compatibility
            except (TypeError, ValueError):
                raise forms.ValidationError("Please enter a valid decimal value.")
            if percentage < 0 or percentage > 100:
                raise forms.ValidationError("Please enter a valid percentage between 0 and 100.")
        return percentage



class MCQForm(forms.ModelForm):
    class Meta:
        model = MCQ
        fields = ['question', 'option1', 'option2', 'option3', 'option4', 'correct_option', 'subject', 'category']


